package net.mcreator.omegavanila.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;

public class EvildiamondshovelToolInInventoryTickProcedure {
	public static void execute(LevelAccessor world, ItemStack itemstack) {
		itemstack.enchant(Enchantments.BLOCK_EFFICIENCY, 5);
	}
}