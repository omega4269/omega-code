package net.mcreator.omegavanila.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.omegavanila.init.OmegavanillaModItems;

public class RosegoldswordItem extends SwordItem {
	public RosegoldswordItem() {
		super(new Tier() {
			public int getUses() {
				return 190;
			}

			public float getSpeed() {
				return 12f;
			}

			public float getAttackDamageBonus() {
				return 0.5f;
			}

			public int getLevel() {
				return 3;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(OmegavanillaModItems.ROSEGOLDINGOT.get()));
			}
		}, 3, -2.3f, new Item.Properties());
	}
}