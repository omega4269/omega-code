/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.omegavanila.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.omegavanila.item.RosegoldswordItem;
import net.mcreator.omegavanila.item.RosegoldshovelItem;
import net.mcreator.omegavanila.item.RosegoldpickaxeItem;
import net.mcreator.omegavanila.item.RosegoldingotItem;
import net.mcreator.omegavanila.item.RosegoldhoeItem;
import net.mcreator.omegavanila.item.RosegoldaxeItem;
import net.mcreator.omegavanila.item.RosegoldarmorItem;
import net.mcreator.omegavanila.item.RawrosegoldItem;
import net.mcreator.omegavanila.item.RawaluminiumItem;
import net.mcreator.omegavanila.item.ObisidipisItem;
import net.mcreator.omegavanila.item.EvildiamondswordItem;
import net.mcreator.omegavanila.item.EvildiamondshovelItem;
import net.mcreator.omegavanila.item.EvildiamondsetItem;
import net.mcreator.omegavanila.item.EvildiamondpickaxeItem;
import net.mcreator.omegavanila.item.EvildiamondhoeItem;
import net.mcreator.omegavanila.item.EvildiamondaxeItem;
import net.mcreator.omegavanila.item.EvildiamondItem;
import net.mcreator.omegavanila.item.AncientcoalItem;
import net.mcreator.omegavanila.item.AmathystemeraldItem;
import net.mcreator.omegavanila.item.AluminiumswordItem;
import net.mcreator.omegavanila.item.AluminiumshovelItem;
import net.mcreator.omegavanila.item.AluminiumpickaxeItem;
import net.mcreator.omegavanila.item.AluminiumingotItem;
import net.mcreator.omegavanila.item.AluminiumaxeItem;
import net.mcreator.omegavanila.item.AluminiumarmorItem;
import net.mcreator.omegavanila.OmegavanillaMod;

public class OmegavanillaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OmegavanillaMod.MODID);
	public static final RegistryObject<Item> ALUMINIUM_BLOCK = block(OmegavanillaModBlocks.ALUMINIUM_BLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> RAWALUMINIUM = REGISTRY.register("rawaluminium", () -> new RawaluminiumItem());
	public static final RegistryObject<Item> ALUMINIUMINGOT = REGISTRY.register("aluminiumingot", () -> new AluminiumingotItem());
	public static final RegistryObject<Item> ALUMINIUMSWORD = REGISTRY.register("aluminiumsword", () -> new AluminiumswordItem());
	public static final RegistryObject<Item> ALUMINIUMPICKAXE = REGISTRY.register("aluminiumpickaxe", () -> new AluminiumpickaxeItem());
	public static final RegistryObject<Item> ALUMINIUMSHOVEL = REGISTRY.register("aluminiumshovel", () -> new AluminiumshovelItem());
	public static final RegistryObject<Item> ALUMINIUMAXE = REGISTRY.register("aluminiumaxe", () -> new AluminiumaxeItem());
	public static final RegistryObject<Item> ROSEGOLD = block(OmegavanillaModBlocks.ROSEGOLD, new Item.Properties().rarity(Rarity.UNCOMMON));
	public static final RegistryObject<Item> RAWROSEGOLD = REGISTRY.register("rawrosegold", () -> new RawrosegoldItem());
	public static final RegistryObject<Item> ROSEGOLDINGOT = REGISTRY.register("rosegoldingot", () -> new RosegoldingotItem());
	public static final RegistryObject<Item> ROSEGOLDSWORD = REGISTRY.register("rosegoldsword", () -> new RosegoldswordItem());
	public static final RegistryObject<Item> ROSEGOLDPICKAXE = REGISTRY.register("rosegoldpickaxe", () -> new RosegoldpickaxeItem());
	public static final RegistryObject<Item> ROSEGOLDAXE = REGISTRY.register("rosegoldaxe", () -> new RosegoldaxeItem());
	public static final RegistryObject<Item> ROSEGOLDSHOVEL = REGISTRY.register("rosegoldshovel", () -> new RosegoldshovelItem());
	public static final RegistryObject<Item> ROSEGOLDHOE = REGISTRY.register("rosegoldhoe", () -> new RosegoldhoeItem());
	public static final RegistryObject<Item> ANCIENTCOALORE = block(OmegavanillaModBlocks.ANCIENTCOALORE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> ANCIENTCOAL = REGISTRY.register("ancientcoal", () -> new AncientcoalItem());
	public static final RegistryObject<Item> ANCIENTCOALBLOCK = block(OmegavanillaModBlocks.ANCIENTCOALBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> EVILDIAMONDORE = block(OmegavanillaModBlocks.EVILDIAMONDORE, new Item.Properties().rarity(Rarity.RARE).fireResistant());
	public static final RegistryObject<Item> EVILDIAMOND = REGISTRY.register("evildiamond", () -> new EvildiamondItem());
	public static final RegistryObject<Item> EVILDIAMONDSWORD = REGISTRY.register("evildiamondsword", () -> new EvildiamondswordItem());
	public static final RegistryObject<Item> EVILDIAMONDPICKAXE = REGISTRY.register("evildiamondpickaxe", () -> new EvildiamondpickaxeItem());
	public static final RegistryObject<Item> EVILDIAMONDAXE = REGISTRY.register("evildiamondaxe", () -> new EvildiamondaxeItem());
	public static final RegistryObject<Item> EVILDIAMONDSHOVEL = REGISTRY.register("evildiamondshovel", () -> new EvildiamondshovelItem());
	public static final RegistryObject<Item> EVILDIAMONDHOE = REGISTRY.register("evildiamondhoe", () -> new EvildiamondhoeItem());
	public static final RegistryObject<Item> D_ALUMINIUM = block(OmegavanillaModBlocks.D_ALUMINIUM, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> DS_ROSEGOLD = block(OmegavanillaModBlocks.DS_ROSEGOLD);
	public static final RegistryObject<Item> EVILDIAMONDBLOCK = block(OmegavanillaModBlocks.EVILDIAMONDBLOCK);
	public static final RegistryObject<Item> RAWROSEGOLDBLOCK = block(OmegavanillaModBlocks.RAWROSEGOLDBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> RAWALUMINIUMBLOCK = block(OmegavanillaModBlocks.RAWALUMINIUMBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> ALUMINIUMBLOCK = block(OmegavanillaModBlocks.ALUMINIUMBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> ROSEGOLDBLOCK = block(OmegavanillaModBlocks.ROSEGOLDBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> OBSIDIPISOREBLOCK = block(OmegavanillaModBlocks.OBSIDIPISOREBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> OBISIDIPIS = REGISTRY.register("obisidipis", () -> new ObisidipisItem());
	public static final RegistryObject<Item> AMATHYSTEMERALD = REGISTRY.register("amathystemerald", () -> new AmathystemeraldItem());
	public static final RegistryObject<Item> AMATHYSTEMERALDBLOCKORE = block(OmegavanillaModBlocks.AMATHYSTEMERALDBLOCKORE, new Item.Properties().rarity(Rarity.RARE).fireResistant());
	public static final RegistryObject<Item> AMATHYSTEMERALDBLOCK = block(OmegavanillaModBlocks.AMATHYSTEMERALDBLOCK, new Item.Properties().rarity(Rarity.RARE));
	public static final RegistryObject<Item> OBISIDPISBLOCK = block(OmegavanillaModBlocks.OBISIDPISBLOCK, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final RegistryObject<Item> ALUMINIUMARMOR_HELMET = REGISTRY.register("aluminiumarmor_helmet", () -> new AluminiumarmorItem.Helmet());
	public static final RegistryObject<Item> ALUMINIUMARMOR_CHESTPLATE = REGISTRY.register("aluminiumarmor_chestplate", () -> new AluminiumarmorItem.Chestplate());
	public static final RegistryObject<Item> ALUMINIUMARMOR_LEGGINGS = REGISTRY.register("aluminiumarmor_leggings", () -> new AluminiumarmorItem.Leggings());
	public static final RegistryObject<Item> ALUMINIUMARMOR_BOOTS = REGISTRY.register("aluminiumarmor_boots", () -> new AluminiumarmorItem.Boots());
	public static final RegistryObject<Item> ROSEGOLDARMOR_HELMET = REGISTRY.register("rosegoldarmor_helmet", () -> new RosegoldarmorItem.Helmet());
	public static final RegistryObject<Item> ROSEGOLDARMOR_CHESTPLATE = REGISTRY.register("rosegoldarmor_chestplate", () -> new RosegoldarmorItem.Chestplate());
	public static final RegistryObject<Item> ROSEGOLDARMOR_LEGGINGS = REGISTRY.register("rosegoldarmor_leggings", () -> new RosegoldarmorItem.Leggings());
	public static final RegistryObject<Item> ROSEGOLDARMOR_BOOTS = REGISTRY.register("rosegoldarmor_boots", () -> new RosegoldarmorItem.Boots());
	public static final RegistryObject<Item> EVILDIAMONDSET_HELMET = REGISTRY.register("evildiamondset_helmet", () -> new EvildiamondsetItem.Helmet());
	public static final RegistryObject<Item> EVILDIAMONDSET_CHESTPLATE = REGISTRY.register("evildiamondset_chestplate", () -> new EvildiamondsetItem.Chestplate());
	public static final RegistryObject<Item> EVILDIAMONDSET_LEGGINGS = REGISTRY.register("evildiamondset_leggings", () -> new EvildiamondsetItem.Leggings());
	public static final RegistryObject<Item> EVILDIAMONDSET_BOOTS = REGISTRY.register("evildiamondset_boots", () -> new EvildiamondsetItem.Boots());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}