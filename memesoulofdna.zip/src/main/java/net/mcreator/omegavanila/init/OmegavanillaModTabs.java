/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.omegavanila.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.omegavanila.OmegavanillaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OmegavanillaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OmegavanillaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OmegavanillaModBlocks.ALUMINIUM_BLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.ROSEGOLD.get().asItem());
			tabData.accept(OmegavanillaModBlocks.ANCIENTCOALORE.get().asItem());
			tabData.accept(OmegavanillaModBlocks.EVILDIAMONDORE.get().asItem());
			tabData.accept(OmegavanillaModBlocks.D_ALUMINIUM.get().asItem());
			tabData.accept(OmegavanillaModBlocks.DS_ROSEGOLD.get().asItem());
			tabData.accept(OmegavanillaModBlocks.AMATHYSTEMERALDBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(OmegavanillaModBlocks.ALUMINIUM_BLOCK.get().asItem());
			tabData.accept(OmegavanillaModItems.RAWALUMINIUM.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMINGOT.get());
			tabData.accept(OmegavanillaModItems.RAWROSEGOLD.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDINGOT.get());
			tabData.accept(OmegavanillaModItems.ANCIENTCOAL.get());
			tabData.accept(OmegavanillaModBlocks.ANCIENTCOALBLOCK.get().asItem());
			tabData.accept(OmegavanillaModItems.EVILDIAMOND.get());
			tabData.accept(OmegavanillaModBlocks.D_ALUMINIUM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(OmegavanillaModItems.ALUMINIUMSWORD.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMAXE.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDSWORD.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSWORD.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDAXE.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMARMOR_HELMET.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMARMOR_CHESTPLATE.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMARMOR_LEGGINGS.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMARMOR_BOOTS.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDARMOR_HELMET.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDARMOR_CHESTPLATE.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDARMOR_LEGGINGS.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDARMOR_BOOTS.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSET_HELMET.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSET_CHESTPLATE.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSET_LEGGINGS.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSET_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(OmegavanillaModItems.ALUMINIUMPICKAXE.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMSHOVEL.get());
			tabData.accept(OmegavanillaModItems.ALUMINIUMAXE.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDSWORD.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDPICKAXE.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDAXE.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDSHOVEL.get());
			tabData.accept(OmegavanillaModItems.ROSEGOLDHOE.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSWORD.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDPICKAXE.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDAXE.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDSHOVEL.get());
			tabData.accept(OmegavanillaModItems.EVILDIAMONDHOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(OmegavanillaModBlocks.ANCIENTCOALBLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.RAWROSEGOLDBLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.RAWALUMINIUMBLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.ALUMINIUMBLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.ROSEGOLDBLOCK.get().asItem());
			tabData.accept(OmegavanillaModBlocks.OBISIDPISBLOCK.get().asItem());
		}
	}
}