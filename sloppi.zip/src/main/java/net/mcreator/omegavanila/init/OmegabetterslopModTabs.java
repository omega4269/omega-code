/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.omegavanila.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.omegavanila.OmegabetterslopMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OmegabetterslopModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OmegabetterslopMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OmegabetterslopModBlocks.ALUMINIUM_BLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.ROSEGOLD.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.ANCIENTCOALORE.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.EVILDIAMONDORE.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.D_ALUMINIUM.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.DS_ROSEGOLD.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.AMATHYSTEMERALDBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.CURSEDSHIT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(OmegabetterslopModBlocks.ALUMINIUM_BLOCK.get().asItem());
			tabData.accept(OmegabetterslopModItems.RAWALUMINIUM.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMINGOT.get());
			tabData.accept(OmegabetterslopModItems.RAWROSEGOLD.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDINGOT.get());
			tabData.accept(OmegabetterslopModItems.ANCIENTCOAL.get());
			tabData.accept(OmegabetterslopModBlocks.ANCIENTCOALBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModItems.EVILDIAMOND.get());
			tabData.accept(OmegabetterslopModBlocks.D_ALUMINIUM.get().asItem());
			tabData.accept(OmegabetterslopModItems.SUPERSUGAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(OmegabetterslopModItems.ALUMINIUMSWORD.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMAXE.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDSWORD.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSWORD.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDAXE.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMARMOR_HELMET.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMARMOR_CHESTPLATE.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMARMOR_LEGGINGS.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMARMOR_BOOTS.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDARMOR_HELMET.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDARMOR_CHESTPLATE.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDARMOR_LEGGINGS.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDARMOR_BOOTS.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSET_HELMET.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSET_CHESTPLATE.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSET_LEGGINGS.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSET_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(OmegabetterslopModItems.ALUMINIUMPICKAXE.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMSHOVEL.get());
			tabData.accept(OmegabetterslopModItems.ALUMINIUMAXE.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDSWORD.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDPICKAXE.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDAXE.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDSHOVEL.get());
			tabData.accept(OmegabetterslopModItems.ROSEGOLDHOE.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSWORD.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDPICKAXE.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDAXE.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDSHOVEL.get());
			tabData.accept(OmegabetterslopModItems.EVILDIAMONDHOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(OmegabetterslopModBlocks.ANCIENTCOALBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.RAWROSEGOLDBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.RAWALUMINIUMBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.ALUMINIUMBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.ROSEGOLDBLOCK.get().asItem());
			tabData.accept(OmegabetterslopModBlocks.OBISIDPISBLOCK.get().asItem());
		}
	}
}