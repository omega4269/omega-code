/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.omegavanila.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.omegavanila.OmegabetterslopMod;

public class OmegabetterslopModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, OmegabetterslopMod.MODID);
	public static final RegistryObject<Potion> SUPERHASTE = REGISTRY.register("superhaste", () -> new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 7200, 3, false, true)));
	public static final RegistryObject<Potion> SUPERSTRENGHT = REGISTRY.register("superstrenght", () -> new Potion(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERSWIFTNESS = REGISTRY.register("superswiftness", () -> new Potion(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERREGENERATION = REGISTRY.register("superregeneration", () -> new Potion(new MobEffectInstance(MobEffects.REGENERATION, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERLEAPING = REGISTRY.register("superleaping", () -> new Potion(new MobEffectInstance(MobEffects.JUMP, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERTURTLEMASTER = REGISTRY.register("superturtlemaster",
			() -> new Potion(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 10800, 4, false, true), new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10800, 4, false, true)));
	public static final RegistryObject<Potion> SUPERNIGHTVISION = REGISTRY.register("supernightvision", () -> new Potion(new MobEffectInstance(MobEffects.NIGHT_VISION, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERINVISIBILITY = REGISTRY.register("superinvisibility", () -> new Potion(new MobEffectInstance(MobEffects.INVISIBILITY, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERFIRERESISTANCE = REGISTRY.register("superfireresistance", () -> new Potion(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERFALLINGRESISTANCE = REGISTRY.register("superfallingresistance", () -> new Potion(new MobEffectInstance(MobEffects.SLOW_FALLING, 10800, 2, false, true)));
	public static final RegistryObject<Potion> SUPERLUCK = REGISTRY.register("superluck", () -> new Potion(new MobEffectInstance(MobEffects.LUCK, 10800, 2, false, true)));
}