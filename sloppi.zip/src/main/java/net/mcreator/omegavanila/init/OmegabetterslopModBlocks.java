/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.omegavanila.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.omegavanila.block.RosegoldblockBlock;
import net.mcreator.omegavanila.block.RosegoldBlock;
import net.mcreator.omegavanila.block.RawrosegoldblockBlock;
import net.mcreator.omegavanila.block.RawaluminiumblockBlock;
import net.mcreator.omegavanila.block.ObsidipisoreblockBlock;
import net.mcreator.omegavanila.block.ObisidpisblockBlock;
import net.mcreator.omegavanila.block.EvildiamondoreBlock;
import net.mcreator.omegavanila.block.EvildiamondblockBlock;
import net.mcreator.omegavanila.block.DsRosegoldBlock;
import net.mcreator.omegavanila.block.DAluminiumBlock;
import net.mcreator.omegavanila.block.CursedshitBlock;
import net.mcreator.omegavanila.block.AncientcoaloreBlock;
import net.mcreator.omegavanila.block.AncientcoalblockBlock;
import net.mcreator.omegavanila.block.AmathystemeraldblockoreBlock;
import net.mcreator.omegavanila.block.AmathystemeraldblockBlock;
import net.mcreator.omegavanila.block.AluminiumblockBlock;
import net.mcreator.omegavanila.block.AluminiumBlock;
import net.mcreator.omegavanila.OmegabetterslopMod;

public class OmegabetterslopModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OmegabetterslopMod.MODID);
	public static final RegistryObject<Block> ALUMINIUM_BLOCK = REGISTRY.register("aluminium_block", () -> new AluminiumBlock());
	public static final RegistryObject<Block> ROSEGOLD = REGISTRY.register("rosegold", () -> new RosegoldBlock());
	public static final RegistryObject<Block> ANCIENTCOALORE = REGISTRY.register("ancientcoalore", () -> new AncientcoaloreBlock());
	public static final RegistryObject<Block> ANCIENTCOALBLOCK = REGISTRY.register("ancientcoalblock", () -> new AncientcoalblockBlock());
	public static final RegistryObject<Block> EVILDIAMONDORE = REGISTRY.register("evildiamondore", () -> new EvildiamondoreBlock());
	public static final RegistryObject<Block> D_ALUMINIUM = REGISTRY.register("d_aluminium", () -> new DAluminiumBlock());
	public static final RegistryObject<Block> DS_ROSEGOLD = REGISTRY.register("ds_rosegold", () -> new DsRosegoldBlock());
	public static final RegistryObject<Block> EVILDIAMONDBLOCK = REGISTRY.register("evildiamondblock", () -> new EvildiamondblockBlock());
	public static final RegistryObject<Block> RAWROSEGOLDBLOCK = REGISTRY.register("rawrosegoldblock", () -> new RawrosegoldblockBlock());
	public static final RegistryObject<Block> RAWALUMINIUMBLOCK = REGISTRY.register("rawaluminiumblock", () -> new RawaluminiumblockBlock());
	public static final RegistryObject<Block> ALUMINIUMBLOCK = REGISTRY.register("aluminiumblock", () -> new AluminiumblockBlock());
	public static final RegistryObject<Block> ROSEGOLDBLOCK = REGISTRY.register("rosegoldblock", () -> new RosegoldblockBlock());
	public static final RegistryObject<Block> OBSIDIPISOREBLOCK = REGISTRY.register("obsidipisoreblock", () -> new ObsidipisoreblockBlock());
	public static final RegistryObject<Block> AMATHYSTEMERALDBLOCKORE = REGISTRY.register("amathystemeraldblockore", () -> new AmathystemeraldblockoreBlock());
	public static final RegistryObject<Block> AMATHYSTEMERALDBLOCK = REGISTRY.register("amathystemeraldblock", () -> new AmathystemeraldblockBlock());
	public static final RegistryObject<Block> OBISIDPISBLOCK = REGISTRY.register("obisidpisblock", () -> new ObisidpisblockBlock());
	public static final RegistryObject<Block> CURSEDSHIT = REGISTRY.register("cursedshit", () -> new CursedshitBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}