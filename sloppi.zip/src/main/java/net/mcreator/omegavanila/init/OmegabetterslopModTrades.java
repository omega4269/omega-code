/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.omegavanila.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class OmegabetterslopModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.ARMORER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 4),

					new ItemStack(Items.DIAMOND, 8), 5, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.FARMER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 2),

					new ItemStack(Items.GOLDEN_APPLE), 4, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.BUTCHER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 10),

					new ItemStack(Items.WITHER_SKELETON_SKULL), 2, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.CARTOGRAPHER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 2),

					new ItemStack(Items.MUSIC_DISC_OTHERSIDE), 1, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.CLERIC) {
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 5),

					new ItemStack(Items.DRAGON_BREATH, 2), 10, 4, 0.05f));
		}
		if (event.getType() == VillagerProfession.FISHERMAN) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 7),

					new ItemStack(Items.COAST_ARMOR_TRIM_SMITHING_TEMPLATE), 5, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.FLETCHER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get()),

					new ItemStack(Items.SPECTRAL_ARROW, 10), 10, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.LEATHERWORKER) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 3),

					new ItemStack(Items.PHANTOM_MEMBRANE, 2), 15, 3, 0.05f));
		}
		if (event.getType() == VillagerProfession.LIBRARIAN) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 10),

					new ItemStack(Items.ENCHANTED_BOOK, 2), 5, 8, 0.05f));
		}
		if (event.getType() == VillagerProfession.MASON) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 2),

					new ItemStack(Blocks.SMOOTH_STONE, 8), 25, 7, 0.05f));
		}
		if (event.getType() == VillagerProfession.SHEPHERD) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 4),

					new ItemStack(Items.COW_SPAWN_EGG, 3), 3, 7, 0.05f));
		}
		if (event.getType() == VillagerProfession.TOOLSMITH) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get()),

					new ItemStack(Items.NETHERITE_SCRAP), 10, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(OmegabetterslopModItems.AMATHYSTEMERALD.get(), 50),

					new ItemStack(Items.NETHERITE_HOE), 1, 50, 0.05f));
		}
	}
}