package net.mcreator.omegavanila.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;

import net.mcreator.omegavanila.procedures.EvildiamondpickaxeItemIsCraftedsmeltedProcedure;
import net.mcreator.omegavanila.init.OmegabetterslopModItems;

import java.util.List;

public class EvildiamondpickaxeItem extends PickaxeItem {
	public EvildiamondpickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 2369;
			}

			public float getSpeed() {
				return 10f;
			}

			public float getAttackDamageBonus() {
				return 4.5f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 16;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(OmegabetterslopModItems.EVILDIAMOND.get()));
			}
		}, 1, -2.8f, new Item.Properties().fireResistant());
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.omegabetterslop.evildiamondpickaxe.description_0"));
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Level world, Player entity) {
		super.onCraftedBy(itemstack, world, entity);
		EvildiamondpickaxeItemIsCraftedsmeltedProcedure.execute(world, itemstack);
	}
}