package net.mcreator.omegavanila.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class RosegoldingotItem extends Item {
	public RosegoldingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON).food((new FoodProperties.Builder()).nutrition(2).saturationMod(0.2f).meat().build()));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 2;
	}
}